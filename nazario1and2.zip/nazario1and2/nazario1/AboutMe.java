package nazario1;

// Xavier Nazario
// Student ID# 2512208
public class AboutMe {
	// Program displaying 4 lines of output
	public static void main(String[] args) {
		// Display my full name
		System.out.println("Xavier Nazario");

		// Display favorite tv show
		System.out.println("Chowder");

		// Display High School and City
		System.out.println("Ridgewood High School Port Richey, FL");

		// Display the expression result
		double result;
		// Declare Variable
		result = (12.5 + 5.5 / 3) / (6.25 * 6 - 5.0);
		// Compute the expression
		System.out.println(result);
		// Display
	}

}
